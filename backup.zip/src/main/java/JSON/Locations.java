package JSON;

public class Locations {
    public Location[] data;

    Locations(){}
}
