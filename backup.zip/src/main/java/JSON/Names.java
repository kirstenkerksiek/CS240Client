package JSON;

public class Names {

    public String[] data;

    public Names(){}
}
