package ServiceTests;

public class AllEventsTest {
}
