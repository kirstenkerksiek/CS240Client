package ServiceTests;

public class EventTest {
}
