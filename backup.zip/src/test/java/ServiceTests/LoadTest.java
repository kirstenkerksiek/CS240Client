package ServiceTests;

public class LoadTest {
}
