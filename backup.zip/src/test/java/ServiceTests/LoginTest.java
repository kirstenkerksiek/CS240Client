package ServiceTests;

public class LoginTest {
}
