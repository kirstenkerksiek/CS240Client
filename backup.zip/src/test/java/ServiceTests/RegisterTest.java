package ServiceTests;

public class RegisterTest {
}
